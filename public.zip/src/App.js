import './App.css';
import Navbar from './component/Navbar';
import TextForm from './component/TextForm';

function App() {
  return (
    <>
    <Navbar title ="TextUtils" about ="About"/>  
    <div className="container" my-3>
    <TextForm heading ="R&P Company"/>
    </div>
    
    
    </>
  );
} 

export default App;
